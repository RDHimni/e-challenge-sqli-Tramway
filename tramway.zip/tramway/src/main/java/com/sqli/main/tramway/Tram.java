package com.sqli.main.tramway;

/**
 * @author rida_dhimni
 *
 * Nov 25, 2019
 *
 * @project tramway
 */

public class Tram {
	
	
	private TramLine tramline;
	private String currentStation;
	private int currentStationNumbre;
	private int tripDuration;
	private boolean nd = false;

	public Tram(TramLine tramLine) {
		// TODO Auto-generated constructor stub
		this.setTramline(tramLine);
		this.setCurrentStation(this.tramline.getListstations().get(currentStationNumbre));
		
	}


	public TramLine getTramline() {
		return tramline;
	}


	public void setTramline(TramLine tramline) {
		this.tramline = tramline;
	}


	public int pickAndRun() {
		// TODO Auto-generated method stub
		boolean d = this.tramline.getMapstatiodisturber().keySet().contains(currentStationNumbre);
		
		if(d) {

			if(!this.nd) {
			setTripDuration(3);
            this.nd = true;
		   }
			else {
				setTripDuration(2+this.tramline.getDurationretartstations().get(currentStationNumbre));
				this.currentStationNumbre ++;
				this.setCurrentStation(this.tramline.getListstations().get(currentStationNumbre));

				
			}
			
			}

		
		else {
		setTripDuration(2+this.tramline.getDurationretartstations().get(currentStationNumbre));
		this.currentStationNumbre ++;
		this.setCurrentStation(this.tramline.getListstations().get(currentStationNumbre));

		}
		
		return getTripDuration();
	}
	
	
	public String getCurrentStation() {
		// TODO Auto-generated method stub
		
		return currentStation;
	}


	public void setCurrentStation(String currentStation) {
		this.currentStation = currentStation;
	}


	public int getTripDuration() {
		return tripDuration;
	}


	public void setTripDuration(int tripDuration) {
		this.tripDuration += tripDuration;
	}

}
