package com.sqli.main.tramway;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @author rida_dhimni
 *
 * Nov 25, 2019
 *
 * @project tramway
 */

public class TramLine {
	
	private List<String> liststations;
	private List<Integer> durationretartstations;
	private Map<Integer,Boolean> mapstatiodisturber ;
 	
	private int durationretart;
	
	public TramLine() {
		// TODO Auto-generated constructor stub
		this.liststations = new LinkedList<>();
		this.durationretartstations = new LinkedList<>();
		this.setMapstatiodisturber(new HashMap<>());
		this.liststations.add("Terminus");
		this.durationretartstations.add(0);
	}

	public void addStation(String station, String ...passengers) {
		// TODO Auto-generated method stub
		
		if(liststations.get(liststations.size()-1).equalsIgnoreCase(station)) {
			durationretartstations.set(durationretartstations.size()-1,
					durationretartstations.get(durationretartstations.size()-1)+3);
			
		}else {
		
		this.liststations.add(station);
		
		for (int i = 0; i < passengers.length; i++) {
			String ps1 = passengers[i];
			
			if(Character.isDigit(ps1.charAt(0))) {
				int nm = Integer.parseInt(ps1.charAt(0)+"");
				String typeps = ps1.substring(1, ps1.length()).trim();

				if(typeps.equalsIgnoreCase("youngMan")) {
					setDurationretart(nm);
				}
				if(typeps.equalsIgnoreCase("oldMan")) {
					setDurationretart(nm*2);

				}
				if(typeps.equalsIgnoreCase("disturber")) {
					//setDurationretart(nm*3);
					this.mapstatiodisturber.put(this.liststations.size()-1, true);
				}				
								
			}else {
				
				if(ps1.equalsIgnoreCase("youngMan")) {
					setDurationretart(1);
				}
				if(ps1.equalsIgnoreCase("oldMan")) {
					setDurationretart(2);

				}
				if(ps1.equalsIgnoreCase("disturber")) {
					//setDurationretart(3);
					this.mapstatiodisturber.put(this.liststations.size()-1, true);

				}				
			}
			
			
		}
		
		durationretartstations.add(getDurationretart());
		this.durationretart =0;
		}
		
	}

	public List<String> getListstations() {
		return liststations;
	}

	public void setListstations(List<String> liststatios) {
		this.liststations = liststatios;
	}

	public int getDurationretart() {
		return durationretart;
	}

	public void setDurationretart(int durationretart) {
		this.durationretart += durationretart;
	}

	public List<Integer> getDurationretartstations() {
		return durationretartstations;
	}

	public void setDurationretartstations(List<Integer> durationretartstations) {
		this.durationretartstations = durationretartstations;
	}

	public Map<Integer,Boolean> getMapstatiodisturber() {
		return mapstatiodisturber;
	}

	public void setMapstatiodisturber(Map<Integer,Boolean> mapstatiodisturber) {
		this.mapstatiodisturber = mapstatiodisturber;
	}

}
